﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Amartinez_midterm.Amartinez_midtermProgram.Person;

using System.Data.SqlClient;


namespace Amartinez_midterm
{
    public partial class Form1 : Form
    {
       

        public Form1()
        {
            InitializeComponent();
            lblFeedback.Text = ""; // clears feedback
        }

        public Form1(int Person_ID)
        {
            InitializeComponent();

            //create temp person in order to retrieve data

            PersonV2 temp = new PersonV2();

            //retrieve data for one person from database

            SqlDataReader dr = temp.FindOnePerson(Person_ID);

            //loop through retrieved data
            while (dr.Read())
            {
                txtID.Text = dr["Person_ID"].ToString();
                txtFirstName.Text = dr["firstName"].ToString();
                txtMiddleName.Text = dr["middleName"].ToString();
                txtLastName.Text = dr["LastName"].ToString();
                txtSt1.Text = dr["street1"].ToString();
                txtSt2.Text = dr["street2"].ToString();
                txtCity.Text = dr["City"].ToString();
                txtState.Text = dr["state"].ToString();
                txtZip.Text = dr["zip"].ToString();
                txtPhone.Text = dr["phone"].ToString();
                txtEmail.Text = dr["email"].ToString();
                txtCellPhone.Text = dr["cellphone"].ToString();
                txtInstagramURL.Text = dr["instagramURL"].ToString();
            }
        }



         private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool completed = true;

            PersonV2 temp = new PersonV2();

            temp.FirstName = txtFirstName.Text;
            temp.MiddleName = txtMiddleName.Text;
            temp.LastName = txtLastName.Text;
            temp.St1 = txtSt1.Text;
            temp.St2 = txtSt2.Text;
            temp.City = txtCity.Text;
            temp.State = txtState.Text;
            
            temp.Email = txtEmail.Text;
            temp.CellPhone = txtCellPhone.Text;
            temp.InstagramURL = txtInstagramURL.Text;

            //check for errros
            if (temp.Feedback.Contains("ERROR"))
            {
                //if so, print feedback and user can make corrections 
                lblFeedback.Text = temp.Feedback;
            }
            else
            {
                //if not, print success messgae
                lblFeedback.Text = temp.AddRecord();
                lblFeedback.Text += $"\nName: {temp.FirstName}";
                //only add if used
                if(temp.MiddleName != "")
                {
                    lblFeedback.Text += $"{temp.MiddleName}";
                }
                lblFeedback.Text += $"{temp.LastName}";
                if(temp.St2.Length > 0)
                {
                    lblFeedback.Text += $"\nAddress: {temp.St1}, {temp.St2}, {temp.City}, {temp.State}, {temp.Zip}";
                }
                else
                {
                    lblFeedback.Text += $"\nAddress: {temp.St1}, {temp.City}, {temp.State}, {temp.Zip}"; 
                }

                lblFeedback.Text += $"\nPhone Number: {temp.Phone} ";
                lblFeedback.Text += $"\nCell Number: {temp.CellPhone} ";
                lblFeedback.Text += $"\n Email: {temp.Email}";
                lblFeedback.Text += $"\nInstagram URL: {temp.InstagramURL}";


            }


            double tempZip;

            if(Double.TryParse(txtZip.Text, out tempZip))
            {
                temp.Zip = tempZip;
            }
            else
            {
                MessageBox.Show("incorrect format. (ex: 02863)", "ERROR");
                completed = false;
            }



            double tempphone;
            if (Double.TryParse(txtPhone.Text, out tempphone))

            {
                temp.Phone = tempphone;
            }
            else
            {
                MessageBox.Show("ERROR");
                completed = false;
            }






            if (!temp.Feedback.Contains("ERROR:"))
            {
                lblFeedback.Text = temp.AddRecord();
            }
            else
            {
                lblFeedback.Text = "\nFirst: \t" + temp.FirstName + "\nMiddle: \t" + temp.MiddleName + "\nLast:\t " + temp.LastName + "\nAddress:\t " + temp.St1 + temp.St2 + "\nCity: \t" + temp.City + "\nState:\t " + temp.State + "\nZip Code: \t" + temp.Zip + "\nPhone Num# :\t" + temp.Phone + temp.CellPhone+"\nCell #:\t" + temp.InstagramURL+"Instagram URL:";
            }








        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void txtZip_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
}
