﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Amartinez_midterm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool completed = true;
            Person temp = new Person();

            temp.FirstName = txtFirstName.Text;
            temp.MiddleName = txtMiddleName.Text;
            temp.LastName = txtLastName.Text;
            temp.St1 = txtSt1.Text;
            temp.St2 = txtSt2.Text;
            temp.City = txtCity.Text;
            temp.State = txtState.Text;
            temp.Email = txtEmail.Text;

            double tempZip;

            if(Double.TryParse(txtZip.Text, out tempZip))
            {
                temp.Zip = tempZip;
            }
            else
            {
                MessageBox.Show("incorrect format. (ex: 02863)", "ERROR");
                completed = false;
            }



            double tempphone;
            if (Double.TryParse(txtPhone.Text, out tempphone))

            {
                temp.Phone = tempphone;
            }
            else
            {
                MessageBox.Show("ERROR");
                completed = false;
            }





            if (temp.Feedback.Contains("ERROR:"))
            {
                lblFeedback.Text = temp.Feedback;
            }
            else
            {
                lblFeedback.Text = "\nFirst: \t" + temp.FirstName + "\nMiddle: \t" + temp.MiddleName + "\nLast:\t " + temp.LastName + "\nAddress:\t " + temp.St1 + temp.St2 + "\nCity: \t" + temp.City + "\nState:\t " + temp.State + "\nZip Code: \t" + temp.Zip + "\nPhone Num# :\t" + temp.Phone;
            }








        }
    }
}
