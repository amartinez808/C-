﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Amartinez_midterm
{
    public partial class ControlPanel : Form
    {
        public ControlPanel()
        {
            InitializeComponent();
        }

        private void ControlPanel_Load(object sender, EventArgs e)
        {

        }
        

       

        private void btnAddABook_Click_1(object sender, EventArgs e)
        {
            Form1 temp = new Form1();   //DONT FORGET TEMP.SHOW BELLOW!!!!!
            temp.Show();
        }

        private void btnSearchBooks_Click_1(object sender, EventArgs e)
        {
            SearchMgr temp = new SearchMgr();
            temp.Show();
        }
    }
}
