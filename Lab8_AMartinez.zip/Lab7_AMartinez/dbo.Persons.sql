﻿CREATE TABLE [dbo].[Persons] (
    [Person_ID]    BIGINT        IDENTITY (1, 1) NOT NULL,
    [FirstName]    NVARCHAR (25) NULL,
    [MiddleName]   NVARCHAR (20) NULL,
    [LastName]     NVARCHAR (40) NULL,
    [Street1]     NVARCHAR (40) NULL,
    [Street2]     NVARCHAR (40) NULL,
    [City]         NVARCHAR (25) NULL,
    [State]        NVARCHAR (2)  NULL,
    [Zip]          NVARCHAR (5)  NULL,
    [Phone]        NVARCHAR (10) NOT NULL,
    [CellPhone]    NVARCHAR (10) NULL,
    [Email]        NVARCHAR (75) NULL,
    [InstagramURL] NVARCHAR (75) NULL,
    CONSTRAINT [PK_Persons] PRIMARY KEY CLUSTERED ([Person_ID] ASC)
);

