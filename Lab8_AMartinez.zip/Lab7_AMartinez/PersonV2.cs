﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;


using static Amartinez_midterm.Amartinez_midtermProgram;

namespace Amartinez_midterm //newest one
{
    class PersonV2 : Person
    {
        private string cellphone;
        private string instagramURL;

        public string CellPhone
        {
            get
            {
                return cellphone;
            }
            set
            {
                if (ValidationLibrary.Phone1(value))
                {
                    cellphone = value;
                }
                else
                {
                    Feedback += "\nERROR: Invalid phone length (ex: 401 359 7970).";
                }

            }

        }

        public string InstagramURL
        {
            get
            {
                return instagramURL;
            }
            set
            {
                if (value == "")
                {
                    Feedback += "ERROR: We Need an Instagram URL  :/";
                }
                else if (!ValidationLibrary.IsValidURL(value))
                {
                    Feedback += "\nERROR: Check Instagram URL.";
                }
                else
                {
                    instagramURL = value;
                } 
            }
        }

        public string AddRecord()
        {
            string result = ""; //Initialize string for storing results

            //connection & Command Objects

            SqlConnection connection = new SqlConnection();
            connection.ConnectionString = @"Server=sql.neit.edu\studentsqlserver,4500;Database=SE245_AMartinez;User ID=SE245_AMartinez;Password=008003147;"; //login info

            //initialize command object & and give command

            SqlCommand command = new SqlCommand();
            command.CommandText = "INSERT INTO Persons (FirstName, MiddleName, LastName, Street1, Street2, City, State, Zip, Phone, Email, CellPhone, InstagramURL) VALUES (@FirstName, @MiddleName, @LastName, @Street1, @Street2, @City, @State, @Zip, @Phone, @Email, @CellPhone, @InstagramURL)";

            //connection to command
            command.Connection = connection;

            //fill in command values
            command.Parameters.AddWithValue("@FirstName", FirstName);
            command.Parameters.AddWithValue("@MiddleName", MiddleName);
            command.Parameters.AddWithValue("@LastName", LastName);
            command.Parameters.AddWithValue("@Street1", Street1);
            command.Parameters.AddWithValue("@Street2", Street2);
            command.Parameters.AddWithValue("@City", City);
            command.Parameters.AddWithValue("@State", State);
            command.Parameters.AddWithValue("@Zip", Zip);
            command.Parameters.AddWithValue("@Phone", Phone);
            command.Parameters.AddWithValue("@Email", Email);
            command.Parameters.AddWithValue("@CellPhone", CellPhone);
            command.Parameters.AddWithValue("@InstagramURL", InstagramURL);
            

            // TRY to connect
            try
            {
                connection.Open(); //OPen Connection

                //run command and store feedback (num of records updated)
                int recs = command.ExecuteNonQuery();

                // set result
                result = $"SUCCESS: you've Inserted {recs} records";

                connection.Close();
            }
            catch (Exception e) //incase that dont work
            {
                result = "ERROR: " + e.Message; //grab error mess and insert in result
            }
            finally
            {

            }

            //return one of two results
            return result;
            

        }

        public DataSet SearchRecords(string firstName, string lastName)
        {
            //dataset needed to be filled in and returned
            DataSet ds = new DataSet();

            //create connection & command objects

            SqlConnection conn = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            conn.ConnectionString = @"Server=sql.neit.edu\studentsqlserver,4500;Database=SE245_AMartinez;User ID=SE245_AMartinez;Password=008003147;";

            //generate command
            string strCmd = "SELECT * FROM Persons WHERE 0=0";

            //add any search criteria if entered
            if(firstName.Length > 0)
            {
                strCmd += $" AND firstName LIKE @firstName";
                cmd.Parameters.AddWithValue("@firstName", $"%{firstName}%");
            }
            if (lastName.Length > 0)
            {
                strCmd += $" AND lastName LIKE @lastName";
                cmd.Parameters.AddWithValue("@lastName", $"%{lastName}%");
            }

            cmd.CommandText = strCmd;
            cmd.Connection = conn;


            //create data adapter
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;

            //TRY to connect
            try
            {
                conn.Open();
                da.Fill(ds, "Persons_Temp");
                conn.Close();
            }
            catch(Exception e)
            {
                //error handling
            }
            //return data
            return ds;
        }

        public SqlDataReader FindOnePerson(int Person_ID)
        {
            // create command and connection objects
            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            //specify connection
            conn.ConnectionString = @"Server=sql.neit.edu\studentsqlserver,4500;Database=SE245_AMartinez;User ID=SE245_AMartinez;Password=008003147;";
            comm.Connection = conn;

            //generate command that selects one entry by persons'ID
            comm.CommandText = "SELECT * FROM Persons WHERE Person_ID = @Person_ID;";
            comm.Parameters.AddWithValue("@Person_ID", Person_ID);

            //connect & retrieve data
            conn.Open();
            return comm.ExecuteReader();
        }




    }
}
