﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Amartinez_midterm
{
    public partial class SearchMgr : Form
    {
        public SearchMgr()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //get data
            PersonV2 temp = new PersonV2();
            //Perform the search we created in PersonV2 class and store returned dataset
            DataSet ds = temp.SearchRecords(txtFirstName.Text, txtLastName.Text);

            //DisplaY Data (dataset)
            dgvResults.DataSource = ds;
            dgvResults.DataMember = ds.Tables["Persons_Temp"].ToString();// point to data grid and table!
        }

        private void dgvResults_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //gather info (rows clicked, then gathers first cells data
            string strPerson_ID = dgvResults.Rows[e.RowIndex].Cells[0].Value.ToString();

            //Display data in pop-up window
            MessageBox.Show(strPerson_ID);

            //Convert the string over to an integer
            int intPerson_ID = Convert.ToInt32(strPerson_ID);

            //create editor form.. passing it one Person_ID
            Form1 Editor = new Form1(intPerson_ID);
            Editor.ShowDialog();
        }
    }
}
