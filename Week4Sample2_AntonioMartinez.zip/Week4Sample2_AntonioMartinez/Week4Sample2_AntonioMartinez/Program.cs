﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Week4Sample2_AntonioMartinez
{
    class ValidationLibrary
    {
        public static bool GotPoop(string temp)
        {
            bool result = false;

            if (temp.Contains("Poop"))
            {
                result = true;

            }

            return result;
        }



        public static bool IsItFilledIn(string temp)
        {
            bool result = false;

            if (temp.Length > 0)
            {
                result = true;
            }

            return result;
        }


        public static bool IsItFilledIn(string temp, int minlen)
        {
            bool result = false;

            if (temp.Length >= minlen)
            {
                result = true;
            }
            return result;
        }

        public static bool IsAFutureDate(DateTime temp)
        {
            bool blnResult;

            if (temp <= DateTime.Now)
            {
                blnResult = false;
            }
            else
            {
                blnResult = true;
            }
            return blnResult;
        }


        public static bool IsValidEmail(string temp)
        {
            bool blnResult = true;

            int atLocation = temp.IndexOf("@");
            int NextatLocation = temp.IndexOf("@", atLocation + 1);


            int periodLocation = temp.LastIndexOf(".");


            if (temp.Length < 8)
            {
                blnResult = false;
            }
            else if (atLocation < 2)
            {
                blnResult = false;
            }
            else if (periodLocation + 2 > (temp.Length))
            {
                blnResult = false;
            }
            return blnResult;

        }


        public static bool IsMinimunAmount(int temp, int min)
        {
            bool blnResult;

            if (temp >= min)
            {
                blnResult = true;
            }
            else
            {
                blnResult = false;
            }
            return blnResult;
        }
    }





    public class BasicTools
    {
        public static void Pause()
        {
            Console.WriteLine("\nPress Any Key to Continue\n");
            Console.ReadLine();
        }
    }
    class Program
    {
        public class Book
        {
            private string title;
            private string authorFirst;
            private string authorLast;
            private string email;
            private DateTime datePublished;
            private int pages;
            private double price;


            public string Title
            {
                get
                {
                    return title;
                }
                set
                {
                    title = value;
                }
            }

            public string AuthorFirst
            {
                get
                {
                    return authorFirst;
                }
                set
                {
                    authorFirst = value;
                }
            }

            public string AuthorLast
            {
                get
                {
                    return authorLast;
                }
                set
                {
                    authorLast = value;
                }
            }

            public string Email
            {
                get
                {
                    return email;
                }
                set
                {
                    if (ValidationLibrary.IsValidEmail(value))
                    {
                        email = value;
                    }
                    else
                    {
                        email = "ERROR: INVALID EMAIL";
                    }
                }
            }

            public DateTime DatePublished
            {
                get
                {
                    return datePublished;
                }

                set
                {
                    if (ValidationLibrary.IsAFutureDate(value) == false)
                    {
                        datePublished = value;
                    }
                    else
                    {
                        datePublished = DateTime.Parse("1/1/1900 12:00 am");
                    }
                }
            }
            public int Pages
            {
                get
                {
                    return pages;
                }
                set
                {
                    pages = value;
                }
            }

            public double Price
            {
                get
                {
                    return price;
                }
                set
                {
                    price = value;
                }
            }









            static void Main(string[] args)
            {
                bool blnResult = false;

                Book temp = new Book();

                Console.WriteLine("\nPLease enter the title: ");
                temp.Title = Console.ReadLine();

                Console.WriteLine("\nPLease enter Author's First name: ");
                temp.AuthorFirst = Console.ReadLine();

                Console.WriteLine("\nPLease enter Author's Last name ");
                temp.AuthorLast = Console.ReadLine();

                Console.WriteLine("\nPLease enter Author's Email: ");
                temp.Email = Console.ReadLine();

                do
                {
                    Console.WriteLine("\nPlease enter the Date Published: ");
                    DateTime dtTempDate;
                    blnResult = DateTime.TryParse(Console.ReadLine(), out dtTempDate);

                    if (blnResult == false)
                    {
                        Console.Write("\nSorry Incorrect date format. Please Try again.         (Ex: 10/31/200) ");
                    }

                } while (blnResult == false);

                do
                {
                    Console.Write("\nPlease enter the # of pages: ");
                    int intTempPages;
                    blnResult = Int32.TryParse(Console.ReadLine(), out intTempPages);

                    if (blnResult == false)
                    {
                        Console.Write("\nSorry incorrect page #. Please try again.  (Ex: 214) ");
                    }

                } while (blnResult == false);

                do
                {
                    Console.Write("\nPLease enter Cost of the Book: $");
                    double dblTempPrice;
                    blnResult = Double.TryParse(Console.ReadLine(), out dblTempPrice);

                    if (blnResult == false)
                    {
                        Console.Write("\nSorry incorreft price. Please try again.  (Ex: 19.50) ");
                    }

                } while (blnResult == false);



                Console.Write("\n\nWe now have the following book: ");
                Console.Write($"\n Title: {temp.Title}");
                Console.Write($"\n written by {temp.AuthorFirst} {temp.AuthorLast}");
                Console.Write($"\n EMail: {temp.Email}");
                Console.Write($"\n Published: {temp.DatePublished.ToShortDateString()}");
                Console.Write($"\n Pages: {temp.Pages}");
                Console.Write($"\n Price: ${temp.Price}");


                BasicTools.Pause();



            }
        }
    }
}
